<?php include("header.php");?>
  <div id="content" class="clearfix">
    <p>&nbsp;</p>
    <h1>Coming Soon!</h1>
    <p>Thank you for visiting our menu. We will be posting our new menu in the very near future.</p>
<?php include("footer.php");?>
